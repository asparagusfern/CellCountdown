//
/***************************************************************************

  ┏┛┻━━━┛┻┓
  ┃　　　━　　　┃
  ┃　┳┛ 　┗┳ ┃
  ┃　　　　　　　┃
  ┃　　　┻　　　┃
  ┗━┓　　　┏━┛
  　　┃　　　┗━━━┓
  　　┃ KEEP AWAY ┣┓
  　　┃ FROM BUGS ┃
  　　┗┓┓┏━┳┓┏┛
  　　 ┃┫┫ ┃┫┫
  　　 ┗┻┛ ┗┻┛

// Created by Bob on 2020/3/3.
// Copyright © 2020 SZJS. All rights reserved.

****************************************************************************/
//

#import "ViewController.h"
#import "BOTextCell.h"

static NSInteger i = 1;

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,strong)NSMutableArray * dataArray;
@property (nonatomic, assign) BOOL isScrollBottom;

@end

@implementation ViewController

- (NSMutableArray *)dataArray {
    if (!_dataArray) {
        self.dataArray = [[NSMutableArray alloc]init];
    }
    return _dataArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    
    NSTimer* timer = [NSTimer timerWithTimeInterval:1.0 target:self selector:@selector(timerAction:) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:timer forMode:NSDefaultRunLoopMode];
}

- (void)timerAction:(NSTimer *)timer {

    NSString *str = [NSString stringWithFormat:@"%ld个大美女",(long)i];
    [self.dataArray addObject:str];
    i++;

    [self.textTabView reloadData];
}
- (void)viewDidAppear:(BOOL)animated {
    self.isScrollBottom = NO;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (self.isScrollBottom) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.005  * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (self.dataArray.count > 0) {
                NSIndexPath *indexPath = [NSIndexPath indexPathForRow:([self.textTabView numberOfRowsInSection:0]-1) inSection:0];
                [self.textTabView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:NO];
            }
        });
    }
    return _dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId = @"BOTextCell";
    BOTextCell *Cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (Cell == nil) {
        Cell = [[[NSBundle mainBundle]loadNibNamed:@"BOTextCell" owner:self options:nil]lastObject];
    }
    
    Cell.titleLab.text = self.dataArray[indexPath.row];
    
    return Cell;
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (self.isScrollBottom == NO) {
        [self.textTabView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.dataArray.count - 1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
        
        if (indexPath.row == self.dataArray.count - 1) {
            self.isScrollBottom = YES;
        }
    }
}

@end
