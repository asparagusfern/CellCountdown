//
/***************************************************************************

  ┏┛┻━━━┛┻┓
  ┃　　　━　　　┃
  ┃　┳┛ 　┗┳ ┃
  ┃　　　　　　　┃
  ┃　　　┻　　　┃
  ┗━┓　　　┏━┛
  　　┃　　　┗━━━┓
  　　┃ KEEP AWAY ┣┓
  　　┃ FROM BUGS ┃
  　　┗┓┓┏━┳┓┏┛
  　　 ┃┫┫ ┃┫┫
  　　 ┗┻┛ ┗┻┛

// Created by Bob on 2020/3/3.
// Copyright © 2020 SZJS. All rights reserved.

****************************************************************************/
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITableView *textTabView;

@end

