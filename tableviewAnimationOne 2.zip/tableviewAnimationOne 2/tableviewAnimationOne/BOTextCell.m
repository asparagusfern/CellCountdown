//
/***************************************************************************

  ┏┛┻━━━┛┻┓
  ┃　　　━　　　┃
  ┃　┳┛ 　┗┳ ┃
  ┃　　　　　　　┃
  ┃　　　┻　　　┃
  ┗━┓　　　┏━┛
  　　┃　　　┗━━━┓
  　　┃ KEEP AWAY ┣┓
  　　┃ FROM BUGS ┃
  　　┗┓┓┏━┳┓┏┛
  　　 ┃┫┫ ┃┫┫
  　　 ┗┻┛ ┗┻┛

// Created by Bob on 2020/3/3.
// Copyright © 2020 SZJS. All rights reserved.

****************************************************************************/
//

#import "BOTextCell.h"

@implementation BOTextCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
